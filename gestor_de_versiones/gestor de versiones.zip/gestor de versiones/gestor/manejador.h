#ifndef MANEJADOR_H
#define MANEJADOR_H
#include<qstring.h>
#include<qfile.h>
#include<qtextstream.h>
#include<ficheros.h>
#include"matriz.h"

//CLASSE QUE SE ENCARGA DE MANEJAR Y ADMINISTRAR LA VERSIONES.

class manejador{
    private:
        QString versiones;  //variable que guarda las versiones del documento
        QString supuesto;   // variable que guarda el delta
        QString historial;  // variable que guarda el historial
        ficheros *archivo = new ficheros();
        matriz *mat = new matriz();
        bool existen_versiones;
    public:
        manejador();
        void crear_base(QString nombre);
        void crear_primeraVer(QString text);

        void set_existen(bool ex);
        bool get_existen();
        void cargar_versiones(QString nombre);

        void iniciar_matriz();
        void ingresar_vertices();
        void ingresar_aristas();
        int convertir_numero(QString numer);
        void borrar_matriz();
        bool matriz_vacia();

        QString obtener_version(QString versi);
        QString generar_delta(QString numero);
        bool filtro(QString numero);
        QString get_supuesto();

        void crear_version(QString text);
        void guardar_version(QString nombre);

        void generar_historial();
        QString get_historial();

};

#endif // MANEJADOR_H

#include "ventana2.h"
#include "ui_ventana2.h"

ventana2::ventana2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ventana2)
{
    ui->setupUi(this);
}

ventana2::~ventana2()
{
    delete ui;
}

void ventana2::set_historial(QString histo){
    /*
     * entradas: ninguna
     * salidas: muestra el historial de versiones
     * retornos: ninguno
     * descripcion: muestra las versiones en orden de creacion en la ventana.
     */
    historial = histo;
    ui->label_2->setText(histo);
}

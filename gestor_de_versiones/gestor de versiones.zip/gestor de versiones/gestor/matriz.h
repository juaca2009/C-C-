#ifndef MATRIZ_H
#define MATRIZ_H
#include<qstring.h>
#include <stdio.h>
#include"elementos.h"

//ESTA CLASE SE ENCARGA DE GENERAR Y ADMINISTRAR LA MATRIZ DE VERSIONES

class matriz{
    private:
        vertice *h;
    public:
        matriz();
        void iniciar_vacio();
        bool vacio();
        int tamano();
        vertice *get_vertice(QString numero);
        bool existe(QString numero);
        void insertar_arista(vertice *origen, QString numero, int n_numero);
        void insertar_vertice(QString numero, int n_numero);
        int cantidad_arista(vertice *origen);
        int cantidad_vertices();
        void anular();

        QString obtener_ultimo_vertice();
        QString obtener_ultima_arista(vertice *origen);
        bool ultimo_vertice(QString numero);
        bool ultima_arista(vertice *origen, QString numero);
        bool vertice_vacio(QString numero);
};

#endif // MATRIZ_H

#include "manejador.h"
#include<qstring.h>
#include<qfile.h>
#include<qtextstream.h>
#include<string.h>
#include<ctype.h>
using namespace std;


manejador::manejador(){
    existen_versiones = false;
    iniciar_matriz();
}

void manejador::crear_base(QString nombre){
    /*
     * entradas: una variable qstring
     * salidas: crear el primer archivo de versiones
     * retornos: ninguno
     * descripcion: crea el primer archivo de control de un documento, con el prefijo s_, como entrada le entra el nombre de un archivo, y se le cambia
     * la extension por una .txt
     */
    QString pref= "s_";
    QString nom;
    pref = pref + nombre;
    for(int i = 0; i < pref.length(); i++){
        if(pref[i] == '.'){
            break;
        }
        nom = nom + pref[i];
    }
    nom = nom + ".txt";
    archivo->guardar_archivo(nom);
    archivo->entrada_texto(versiones);
}

void manejador::crear_primeraVer(QString text){
    /*
     * entradas: variable qstring
     * salidas: guarda la primera version en la variable versiones de la clase manejador
     * retornos: ninguno
     * descripcion: guarda la primera version en la variable versiones de la clase manejador creando su respectivo numero y tomando el respectivo
     * texto a guardar
     */
    versiones = versiones + "$" + "1.1" + "$";
    versiones = versiones + "\n";
    versiones = versiones +  '^' + text + '^';
}

void manejador::crear_version(QString text){
    /*entradas: una variable qstring
    * salidas: crea una version
    * retornos: ninguno
    * descripcion: crea una version tomando como numero de version el numero del suouesto o delta
   */
    versiones = versiones + "\n";
    versiones = versiones + "$" + supuesto + "$";
    versiones = versiones + "\n";
    versiones = versiones +  '^' + text + '^';

}

void manejador::guardar_version(QString nombre){
    /*entradas: una variable qstring
    * salidas: actualiza el archivo de versiones
    * retornos: ninguno
    * descripcion: guarda el contenido de la variable versiones en el archivo de versiones correspondiente
   */
    QString pref= "s_";
    QString nom;
    pref = pref + nombre;
    for(int i = 0; i < pref.length(); i++){
        if(pref[i] == '.'){
            break;
        }
        nom = nom + pref[i];
    }
    nom = nom + ".txt";
    archivo->guardar_archivo(nom);
    archivo->entrada_texto(versiones);
}

void manejador::set_existen(bool ex){
    existen_versiones = ex;
}

bool manejador::get_existen(){
    return existen_versiones;
}

void manejador::cargar_versiones(QString nombre){
    /*entradas: una variable qstring
    * salidas: guarda el contenido de un archivo en la variable de versiones
    * retornos: ninguno
    * descripcion: guarda el contenido de una archivo de versiones a la variable de versiones
   */
    QString defecto = "s_";
    QString nombre_solo;
    int i;
    for(i = 0; i < nombre.length(); i++){
        if(nombre[i] == '.'){
            break;
        }
    }
    i = i -1;
    for(int j = 0; j <= i; j++){
        nombre_solo = nombre_solo + nombre[j];
    }
    nombre_solo = nombre_solo + ".txt";
    defecto = defecto + nombre_solo;
    archivo->abrir_archivo(defecto);
    versiones = archivo->salida_texto();
}

void manejador::ingresar_vertices(){
    /*entradas: ninguna
    * salidas: ingresa los numero de versiones a la matriz de versiones
    * retornos: ninguno
    * descripcion: ingresa los numero de versiones a la rama principal de la matriz de versiones
   */
    for(int i = 0; i <= versiones.length(); i++){
        QString version;
        if(versiones[i] == '$'){
            i = i +1;
            while(versiones[i] != '$'){
                version = version + versiones[i];
                i = i + 1;
            }
            if(version.length() == 3){
                int val;
                val = convertir_numero(version);
                mat->insertar_vertice(version, val);
            }
        }
    }
}

void manejador::ingresar_aristas(){
    /*entradas: ninguna
    * salidas: ingresa los numeros de versiones a la matriz de versiones
    * retornos: ninguno
    * descripcion: ingresa los numeros de versiones a las ramas secundarias de la matriz de versiones
   */
    for(int i = 0; i <= versiones.length(); i++){
        QString version;
        if(versiones[i] == '$'){
            i = i + 1;
            while(versiones[i] != '$'){
                version = version + versiones[i];
                i = i + 1;
            }
            if(version.length() > 3){
                QString coor;
                int val;
                for(int j = 0; j < 3; j++){
                    coor = coor + version[j];
                }
                val = convertir_numero(version);
                mat->insertar_arista(mat->get_vertice(coor), version, val);
            }
        }
    }
}

int manejador::convertir_numero(QString numer){
    /*entradas: una variable qstring
    * salidas: covierte un qstring a un int
    * retornos: retorna un entero
    * descripcion: convierte el numero de una version a entero
   */
    string num;
    string nume;
    num = numer.toStdString();
    for(int i = 0; i <= num.length(); i++){
        if(num[i] != '.'){
            nume = nume + num[i];
        }
    }
    int val;
    val = atoi(nume.c_str());
    if(val >= 100 && val <= 999){
        val = val * 10;
    }
    if(val >= 10 && val <= 99){
        val = val * 100;
    }
    return val;
}

void manejador::borrar_matriz(){
    mat->anular();
}

QString manejador::obtener_version(QString versi){
    /*entradas: una variable qstring
    * salidas: obtiene el texto de la version que ingresa
    * retornos: un qstring
    * descripcion: obtiene el texto que tenga el numero de version que se le entra por parametro
   */
    for(int i = 0; i <= versiones.length(); i++){
        QString version;
        if(versiones[i] == '$'){
            i = i + 1;
            while(versiones[i] != '$'){
                version = version + versiones[i];
                i = i + 1;
            }
            if(version == versi){
                QString texto;
                i = i + 3;
                while(versiones[i] != '^'){
                    texto = texto + versiones[i];
                    i = i + 1;
                }
                return texto;
            }
        }
    }
}

QString manejador::generar_delta(QString numero){
    /*entradas: una variable qstring
    * salidas: el texto de la version que se desea obtener y genera el delta
    * retornos: una variable qstring
    * descripcion: genera el delta o supuesto y retorna el texto correspondiente
   */
    QString text;
    if(numero.length() == 1){  //
        QString def;
        QString ver;
        def = ".1";
        ver = numero;
        ver = ver + def;
        supuesto = ver;
        text = obtener_version(mat->obtener_ultimo_vertice());
        return text;
    }

    if(numero.length() == 5){  //
        QString rama, ayu;
        QString nu;
        QString num;
        num = ".";
        for(int i = 0; i <= 2; i++){
            rama = rama + numero[i];
        }
        ayu = rama;
        nu = numero[4];
        nu = nu + ".1";
        num = num + nu;
        rama = rama + num;
        supuesto = rama;
        text = obtener_version(mat->obtener_ultima_arista(mat->get_vertice(ayu)));
        return text;
    }

    if(numero.length() == 3){    //
        if(mat->ultimo_vertice(numero) == true){
            QString un;
            QString ul, ult;
            string va;
            int f;
            un = numero[0];
            un = un + ".";
            ul = numero[2];
            va = ul.toStdString();
            f = atoi(va.c_str());
            f = f + 1;
            va = to_string(f);
            ult = va.c_str();
            un = un + ult;
            supuesto = un;
            text = obtener_version(numero);
            return text;
        }

        if(mat->ultimo_vertice(numero) == false){
            if(mat->vertice_vacio(numero) == true){
                QString ram;
                ram = numero;
                ram = ram + ".1.1";
                supuesto = ram;
                text = obtener_version(numero);
                return text;
            }
            else{
                QString ve, re, ult;
                string val;
                int t;
                ve = mat->obtener_ultima_arista(mat->get_vertice(numero));
                for(int j = 0; j <= 5; j++){
                    re = re + ve[j];
                }
                ult = ve[6];
                val = ult.toStdString();
                t = atoi(val.c_str());
                t = t + 1;
                val = to_string(t);
                ult = val.c_str();
                re = re + ult;
                supuesto = re;
                text = obtener_version(numero);
                return text;
            }

        }
    }

    if(numero.length() == 7){   //
        QString rama;
        for(int t = 0; t <= 2; t++){
            rama = rama + numero[t];
        }
        if(mat->ultima_arista(mat->get_vertice(rama), numero) == true){
            QString ma, ult;
            string val;
            int y;
            for(int u = 0; u <= 5; u++){
                ma = ma + numero[u];
            }
            ult = numero[6];
            val = ult.toStdString();
            y = atoi(val.c_str());
            y = y + 1;
            val = to_string(y);
            ult = val.c_str();
            ma = ma + ult;
            supuesto = ma;
            text = obtener_version(numero);
            return text;
        }
        else{
            QString ma, ult, aa;
            string val;
            int y;
            aa = mat->obtener_ultima_arista(mat->get_vertice(rama));
            for(int u = 0; u <= 5; u++){
                ma = ma + aa[u];
            }
            ult = numero[6];
            val = ult.toStdString();
            y = atoi(val.c_str());
            y = y + 1;
            val = to_string(y);
            ult = val.c_str();
            ma = ma + ult;
            supuesto = ma;
            text = obtener_version(numero);
            return text;
        }
    }
}

bool manejador::filtro(QString numero){
    /*entradas: una variable qstring
    * salidas: filtra la entrada
    * retornos: un booleano
    * descripcion: filtra la entrada que se le haga a la hora de ingresar el numero de version que se desea
   */
    if(numero.length() == 1){
        string val;
        val = numero.toStdString();
        if(isdigit(val[0]) == false){
            return false;
        }
        QString valor;
        valor = mat->obtener_ultimo_vertice();
        string prime, un;
        int a, b;
        prime = valor.toStdString();
        un = prime[0];
        a = atoi(val.c_str());
        b = atoi(un.c_str());
        if(a <= b){
            return false;
        }
        return true;
    }


    if(numero.length() == 5){
        string val;
        val = numero.toStdString();
        if(isdigit(val[0]) == false && isdigit(val[2]) == false && isdigit(val[4]) == false){
            return false;
        }
        if(val[1] != '.' && val[3] != '.'){
                return false;
        }

        QString ram;
        for(int i = 0; i <= 2; i++){
            ram = ram + numero[i];
        }
        if(mat->existe(ram) == false){
            return false;
        }
        QString valor;
        valor = mat->obtener_ultima_arista(mat->get_vertice(ram));
        string aa,bb;
        aa = numero.toStdString();
        bb = valor.toStdString();
        string ul;
        string uli;
        ul = bb[4];
        uli = aa[4];
        int a,b;
        a = atoi(uli.c_str());
        b = atoi(ul.c_str());
        if(a <= b){
            return false;
        }
        return true;
    }

    if(numero.length() == 3){
        string val;
        val = numero.toStdString();
        if(isdigit(val[0]) == false && isdigit(val[2]) == false){
            return false;
        }
        if(val[1] != '.'){
            return false;
        }

        if(mat->existe(numero) == false){
            return false;
        }
        return true;
    }

    if(numero.length() == 7){
        string val;
        val = numero.toStdString();
        if(isdigit(val[0]) == false && isdigit(val[2]) == false && isdigit(val[4]) == false && isdigit(val[6]) == false){
            return false;
        }
        if(numero[1] != '.' && numero[3] != '.' && numero[5] != '.'){
            return false;
        }
        QString ram;
        for(int i = 0; i <= 2; i++){
            ram = ram + numero[i];
        }
        if(mat->existe(ram) == false){
            return false;
        }

        if(mat->existe(numero) == false){
            return false;
        }
        return true;
    }
    return false;
}

QString manejador::get_supuesto(){
    return supuesto;
}

bool manejador::matriz_vacia(){
    return mat->vacio();
}

void manejador::iniciar_matriz(){
     mat->iniciar_vacio();
}

void manejador::generar_historial(){
    for(int i = 0; i <= versiones.length(); i++){
        QString version;
        if(versiones[i] == '$'){
            i = i + 1;
            while(versiones[i] != '$'){
                version = version + versiones[i];
                i = i + 1;
            }
            historial = historial + version;
            historial = historial + "\n";

        }
    }
}

QString manejador::get_historial(){
    return historial;
}

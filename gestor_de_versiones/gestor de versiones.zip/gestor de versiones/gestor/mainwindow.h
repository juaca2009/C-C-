#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<ventana.h>
#include<ventana2.h>
#include<ficheros.h>
#include<manejador.h>

/*
 * proyecto creado por: juan camilo hernandez saavedra
 * codigo: 8931911
 * GESTOR DE VERSIONES - PROGRAMACION ORIENTADA A OBJETOS
 * fecha: 3/06/2018
*/

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_abrir_triggered();
    void on_guardar_como_triggered();
    void on_salir_triggered();
    void on_actioncopiar_triggered();
    void on_actioncortar_triggered();
    void on_actionpegar_triggered();
    void on_actioningresar_version_triggered();
    void on_actioncrear_archio_base_triggered();
    void on_actionobtener_version_triggered();
    void on_actionmodificar_version_triggered();
    void on_actionmostrar_historial_triggered();

private:
    Ui::MainWindow *ui;
    ficheros *archi = new ficheros();
    manejador *mane = new manejador();
    ventana *vent = new ventana();
    ventana2 *vent2 = new ventana2();
    bool guardado;                       //variables que son usadas en la apartado grafico del programa.
    bool obtenido;
    bool modo_version;
    bool abierto;

};

#endif // MAINWINDOW_H

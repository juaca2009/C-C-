#ifndef VENTANA2_H
#define VENTANA2_H

#include <QDialog>

//VENTANA QUE MUESTRA EL HISTORIAL DE VERSIONES

namespace Ui {
class ventana2;
}

class ventana2 : public QDialog
{
    Q_OBJECT

public:
    explicit ventana2(QWidget *parent = 0);
    void set_historial(QString histo);
    ~ventana2();

private:
    Ui::ventana2 *ui;
    QString historial;
};

#endif // VENTANA2_H

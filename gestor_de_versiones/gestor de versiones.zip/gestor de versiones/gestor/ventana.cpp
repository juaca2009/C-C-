#include "ventana.h"
#include<qstring.h>
#include "ui_ventana.h"

ventana::ventana(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ventana)
{
    ui->setupUi(this);
    aprovacion = false;
}

ventana::~ventana()
{
    delete ui;
}

void ventana::on_buttonBox_accepted(){
    /*
     * entradas: ninguna
     * salidas: carga el numero de version que se pidio
     * retornos: ninguno
     * descripcion: al undir positivamente carga el dato que ingreso el usuario, este dato se filtra en la clase de manejador,
     */
    entrada = ui->plainText->toPlainText();
    if(entrada == ""){
        aprovacion = false;
    }
    else{
        aprovacion = true;
    }
    ui->plainText->setPlainText("");
    hide();
}

//boton de cancelar.
void ventana::on_buttonBox_rejected(){
    aprovacion = false;
     ui->plainText->setPlainText("");
}

void ventana::set_aprovacion(bool apro){
    aprovacion = apro;
}

bool ventana::get_aprovacion(){
    return aprovacion;
}

QString ventana::get_entrada(){
    return entrada;
}

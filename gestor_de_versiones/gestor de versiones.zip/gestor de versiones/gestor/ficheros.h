#ifndef FICHEROS_H
#define FICHEROS_H
#include<qstring.h>
#include<qfile.h>
#include<qtextstream.h>
#include<qdir.h>

//clase encargada de la apertura y manejo de archivos.

class ficheros{
    private:
        QFile arch;
        QString nombre;
    public:
        ficheros();
        void abrir_archivo(QString nombre_arch);
        void guardar_archivo(QString nombre_arch);
        QString salida_texto();
        void entrada_texto(QString text);
        bool apertura();
        QString erro_string();
        void obtener_nombre(QString nom);
        QString get_nombre();
        bool verificar_versiones();
        void set_nombre(QString nom);
};

#endif // FICHEROS_H

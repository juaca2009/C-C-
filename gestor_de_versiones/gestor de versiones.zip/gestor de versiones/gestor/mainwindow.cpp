#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<qfiledialog.h>
#include<qtextstream.h>
#include<qfile.h>
#include<qmessagebox.h>

MainWindow::MainWindow(QWidget *parent) :    //constructor de la ventana principal
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setCentralWidget(ui->plainTextEdit);
    guardado = false;
    obtenido = false;
    modo_version = false;
    abierto = false;
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_abrir_triggered(){
    /*
     * entradas: ninguna
     * salidas: carga la informacion de los archivos
     * retornos: ninguno
     * descripcion: abre los archivos y muestra su contenido en la hoja en blanco, ademas de cargar elementos importantes de la clase manejador que
     * son de alta importancia para el funcionamiento correcto. La variable abierto  se usa para determinar si se abre un archivo con uno abierto o no.
     */
    if(modo_version == true){
        QMessageBox::critical(this, "error al usar esta funcion", "primero modifique el archivo que obtuvo");
        return;
    }
    if(abierto == true){
        ui->plainTextEdit->setPlainText("");
        mane->borrar_matriz();
        if(mane->get_existen() == true){
            mane->guardar_version(archi->get_nombre());
        }
        archi->set_nombre("");
        vent2->set_historial("");
        QString nombre_archivo;
        nombre_archivo = QFileDialog::getOpenFileName(this, "abrir");
        if(nombre_archivo.isEmpty()){
            return;
        }
        archi->obtener_nombre(nombre_archivo);
        archi->abrir_archivo(nombre_archivo);
        if(!archi->apertura()){
            QMessageBox::critical(this, "error al abrir el archivo", archi->erro_string());
            return;
        }
        mane->set_existen(archi->verificar_versiones());
        if(mane->get_existen() == false){
            QMessageBox::warning(this, "ADVERTENCIA", "el archivo que acaba de abrir no posee versiones en el manejador.");
        }
        if(mane->get_existen() == true){
            mane->cargar_versiones(archi->get_nombre());
            mane->ingresar_vertices();
            mane->ingresar_aristas();
            mane->generar_historial();
            vent2->set_historial(mane->get_historial());
        }
        ui->plainTextEdit->setPlainText(archi->salida_texto());
        guardado = true;
        abierto = true;
    }

    if(abierto == false){
        QString nombre_archivo;
        nombre_archivo = QFileDialog::getOpenFileName(this, "abrir");
        if(nombre_archivo.isEmpty()){
            return;
        }
        archi->obtener_nombre(nombre_archivo);
        archi->abrir_archivo(nombre_archivo);
        if(!archi->apertura()){
            QMessageBox::critical(this, "error al abrir el archivo", archi->erro_string());
            return;
        }
        mane->set_existen(archi->verificar_versiones());
        if(mane->get_existen() == false){
            QMessageBox::warning(this, "ADVERTENCIA", "el archivo que acaba de abrir no posee versiones en el manejador.");
        }
        if(mane->get_existen() == true){
            mane->cargar_versiones(archi->get_nombre());
            mane->ingresar_vertices();
            mane->ingresar_aristas();
            mane->generar_historial();
            vent2->set_historial(mane->get_historial());
        }
        ui->plainTextEdit->setPlainText(archi->salida_texto());
        guardado = true;
        abierto = true;
    }


}

void MainWindow::on_guardar_como_triggered(){
    /*
     * entradas: ninguna
     * salidas: guarda los archivos
     * retornos: ninguno
     * descripcion: guarda el contenido de la hoja en un archivo con el nombre que se desee.
     */
    if(modo_version == true){
        QMessageBox::critical(this, "error al usar esta funcion", "primero modifique el archivo que obtuvo");
        return;
    }
    QString nombre_archivo;
    nombre_archivo = QFileDialog::getSaveFileName(this, "guardar archivo");
    if(nombre_archivo.isEmpty()){
        return;
    }
    archi->obtener_nombre(nombre_archivo);
    archi->guardar_archivo(nombre_archivo);
    if(!archi->apertura()){
        QMessageBox::critical(this, "un error ha ocurrido", archi->erro_string());
        return;
    }
    archi->entrada_texto(ui->plainTextEdit->toPlainText());
    guardado = true;
}

void MainWindow::on_salir_triggered(){
    /*
     * entradas: ninguna
     * salidas: cierra la aplicacion
     * retornos: ninguno
     * descripcion: cierra las ventanas de la aplicacion y elimina la matriz de versiones, si es que esta llena.
     */
    if(modo_version == true){
        QMessageBox::critical(this, "error al salir", "primero modifique el archivo que obtuvo");
        return;
    }
    if(mane->matriz_vacia() == false){
         mane->borrar_matriz();
    }
    vent->close();
    vent2->close();
    close();
}

//copiar texto
void MainWindow::on_actioncopiar_triggered(){
    ui->plainTextEdit->copy();
}

//cortar texto
void MainWindow::on_actioncortar_triggered(){
    ui->plainTextEdit->cut();
}

//pegar texto
void MainWindow::on_actionpegar_triggered(){
    ui->plainTextEdit->paste();
}

void MainWindow::on_actioncrear_archio_base_triggered(){
    /*
     * entradas: ninguna
     * salidas: genera archivo de versiones
     * retornos: ninguno
     * descripcion: crea el archivo de versiones por primera vez, solo con las condiciones de que el archivo no tenga un archivo de versiones ya
     * creado y que el archivo en cuestion este guardado.
     */
    if(modo_version == true){
        QMessageBox::critical(this, "error al usar esta funcion", "primero modifique el archivo que obtuvo");
        return;
    }
    if(guardado == false){
        QMessageBox::critical(this, "error al guardar version", "el archivo no esta guardado");
        return;
    }
    if(mane->get_existen() == true){
        QMessageBox::critical(this, "error", "este archivo ya tiene un archivo base");
        return;
    }
    mane->crear_primeraVer(ui->plainTextEdit->toPlainText());
    mane->crear_base(archi->get_nombre());
    mane->cargar_versiones(archi->get_nombre());
    mane->ingresar_vertices();
    mane->ingresar_aristas();
    mane->set_existen(true);
    mane->generar_historial();
    vent2->set_historial(mane->get_historial());

}

void MainWindow::on_actioningresar_version_triggered(){
    /*
     * entradas: ninguna
     * salidas: muestra ventana
     * retornos ninguno
     * decripcion: muestra la ventana para ingresar la version que se desea obtener
     */
    vent->setModal(true);
    vent->show();
}

void MainWindow::on_actionobtener_version_triggered(){
    /*
     * entradas: ninguna
     * salidas: obtiene version y genera delta.
     * retorno: ninguna
     * descripcion: muestra en pantalla la version deseada y genera el delta correspondiente, al usar esta funcion bloquea las funciones de guardar
     * salir abrir y generar archivo base hasta que se modifique o guarde la version que obtuvo.
     */
    if(guardado == false){
        QMessageBox::critical(this, "error al usar esta funcion", "el archivo no esta guardado");
        return;
    }
    if(mane->get_existen() == false){
        QMessageBox::critical(this, "error al usar esta funcion", "el archivo no tiene versiones");
        return;
    }
    if(vent->get_aprovacion() == false){
        QMessageBox::critical(this, "error al usar esta funcion", "no ha ingresado la version en el apartado de ingresar version");
        return;
    }
    if(mane->filtro(vent->get_entrada()) == false){
        QMessageBox::critical(this, "error", "ingrese un dato correcto");
        return;
    }
    if(mane->filtro(vent->get_entrada()) == true){
        ui->plainTextEdit->setPlainText(mane->generar_delta(vent->get_entrada()));
        QMessageBox::information(this, "se genero el delta", mane->get_supuesto());
        obtenido = true;
        modo_version = true;
    }

}

void MainWindow::on_actionmodificar_version_triggered(){
    /*
     * entradas: ninguna
     * salidas: guarda la version obtenida con el delta generado
     * retornos: ninguno
     * descripcion: guarda la version en el archivo de versiones con la version obtenido anteriormente, ovbiamente modificada. ademas de actializar
     * ciertas estructuras de la clase manejador.
     */
    if(guardado == false){
        QMessageBox::critical(this, "error al usar esta funcion", "el archivo no esta guardado");
        return;
    }
    if(mane->get_existen() == false){
        QMessageBox::critical(this, "error al usar esta funcion", "el archivo no tiene versiones");
        return;
    }
    if(obtenido == false){
        QMessageBox::critical(this, "error al usar esta funcion", "primero obtenga una version");
        return;
    }
    mane->crear_version(ui->plainTextEdit->toPlainText());
    mane->guardar_version(archi->get_nombre());
    mane->cargar_versiones(archi->get_nombre());
    mane->ingresar_vertices();
    mane->ingresar_aristas();
    mane->generar_historial();
    vent2->set_historial("");
    vent2->set_historial(mane->get_historial());
    modo_version = false;
    obtenido = false;
    QMessageBox::information(this, "modificar version", "se ha modificado con el numero de version" + mane->get_supuesto());

}

void MainWindow::on_actionmostrar_historial_triggered(){
    /*
     * entradas: ninguna
     * salidas: carga el historial de versiones a la ventana correspondiente
     * retornos:ninguno
     * descripcion: carga el historial de versiones generado en la clase manejador a la ventana correspondiente.
     */
    if(guardado == false){
        QMessageBox::critical(this, "error al usar esta funcion", "el archivo no esta guardado");
        return;
    }
    if(mane->get_existen() == false){
        QMessageBox::critical(this, "error al usar esta funcion", "el archivo no tiene versiones");
        return;
    }
    if(modo_version == true){
        QMessageBox::critical(this, "error al usar esta funcion", "primero modifique el archivo que obtuvo");
        return;
    }
    vent2->setModal(true);
    vent2->show();
}

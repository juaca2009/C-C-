#ifndef VENTANA_H
#define VENTANA_H

#include <QDialog>
#include<qstring.h>

//VENTANA QUE RECIBE LA VERSION DESEEADA.

namespace Ui {
class ventana;
}

class ventana : public QDialog
{
    Q_OBJECT

public:
    explicit ventana(QWidget *parent = 0);
    void set_aprovacion(bool apro);
    bool get_aprovacion();
    QString get_entrada();
    ~ventana();

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::ventana *ui;
    bool aprovacion;  //variable que se encarga de regular la funcion obtener, en caso de que no se haya obtenido ningun dato de esta clase no permitira acceder a la opcion obtener.
    QString entrada;
};

#endif // VENTANA_H

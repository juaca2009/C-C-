/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *abrir;
    QAction *guardar_como;
    QAction *salir;
    QAction *actioncrear_archio_base;
    QAction *actionobtener_version;
    QAction *actionmodificar_version;
    QAction *actioncopiar;
    QAction *actioncortar;
    QAction *actionpegar;
    QAction *actioningresar_version;
    QAction *actionmostrar_historial;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QPlainTextEdit *plainTextEdit;
    QMenuBar *menuBar;
    QMenu *menuarchivo;
    QMenu *menumanejo_versiones;
    QMenu *menuedicion;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(400, 300);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icono programa.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        abrir = new QAction(MainWindow);
        abrir->setObjectName(QStringLiteral("abrir"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/abrir.png"), QSize(), QIcon::Normal, QIcon::Off);
        abrir->setIcon(icon1);
        guardar_como = new QAction(MainWindow);
        guardar_como->setObjectName(QStringLiteral("guardar_como"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/guardar.png"), QSize(), QIcon::Normal, QIcon::Off);
        guardar_como->setIcon(icon2);
        salir = new QAction(MainWindow);
        salir->setObjectName(QStringLiteral("salir"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/cerrar.png"), QSize(), QIcon::Normal, QIcon::Off);
        salir->setIcon(icon3);
        actioncrear_archio_base = new QAction(MainWindow);
        actioncrear_archio_base->setObjectName(QStringLiteral("actioncrear_archio_base"));
        actionobtener_version = new QAction(MainWindow);
        actionobtener_version->setObjectName(QStringLiteral("actionobtener_version"));
        actionmodificar_version = new QAction(MainWindow);
        actionmodificar_version->setObjectName(QStringLiteral("actionmodificar_version"));
        actioncopiar = new QAction(MainWindow);
        actioncopiar->setObjectName(QStringLiteral("actioncopiar"));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/copiar.png"), QSize(), QIcon::Normal, QIcon::Off);
        actioncopiar->setIcon(icon4);
        actioncortar = new QAction(MainWindow);
        actioncortar->setObjectName(QStringLiteral("actioncortar"));
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/cortar.png"), QSize(), QIcon::Normal, QIcon::Off);
        actioncortar->setIcon(icon5);
        actionpegar = new QAction(MainWindow);
        actionpegar->setObjectName(QStringLiteral("actionpegar"));
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/pegar.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionpegar->setIcon(icon6);
        actioningresar_version = new QAction(MainWindow);
        actioningresar_version->setObjectName(QStringLiteral("actioningresar_version"));
        actionmostrar_historial = new QAction(MainWindow);
        actionmostrar_historial->setObjectName(QStringLiteral("actionmostrar_historial"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        plainTextEdit = new QPlainTextEdit(centralWidget);
        plainTextEdit->setObjectName(QStringLiteral("plainTextEdit"));

        gridLayout->addWidget(plainTextEdit, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 400, 21));
        menuarchivo = new QMenu(menuBar);
        menuarchivo->setObjectName(QStringLiteral("menuarchivo"));
        menumanejo_versiones = new QMenu(menuBar);
        menumanejo_versiones->setObjectName(QStringLiteral("menumanejo_versiones"));
        menuedicion = new QMenu(menuBar);
        menuedicion->setObjectName(QStringLiteral("menuedicion"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuarchivo->menuAction());
        menuBar->addAction(menumanejo_versiones->menuAction());
        menuBar->addAction(menuedicion->menuAction());
        menuarchivo->addAction(abrir);
        menuarchivo->addAction(guardar_como);
        menuarchivo->addAction(salir);
        menumanejo_versiones->addAction(actioncrear_archio_base);
        menumanejo_versiones->addAction(actionobtener_version);
        menumanejo_versiones->addAction(actionmodificar_version);
        menumanejo_versiones->addAction(actioningresar_version);
        menumanejo_versiones->addAction(actionmostrar_historial);
        menuedicion->addAction(actioncopiar);
        menuedicion->addAction(actioncortar);
        menuedicion->addAction(actionpegar);
        mainToolBar->addAction(abrir);
        mainToolBar->addAction(guardar_como);
        mainToolBar->addAction(actioncopiar);
        mainToolBar->addAction(actioncortar);
        mainToolBar->addAction(actionpegar);
        mainToolBar->addAction(salir);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "gestor", nullptr));
        abrir->setText(QApplication::translate("MainWindow", "abrir", nullptr));
#ifndef QT_NO_SHORTCUT
        abrir->setShortcut(QApplication::translate("MainWindow", "Ctrl+A", nullptr));
#endif // QT_NO_SHORTCUT
        guardar_como->setText(QApplication::translate("MainWindow", "guardar como", nullptr));
#ifndef QT_NO_SHORTCUT
        guardar_como->setShortcut(QApplication::translate("MainWindow", "Ctrl+G", nullptr));
#endif // QT_NO_SHORTCUT
        salir->setText(QApplication::translate("MainWindow", "salir", nullptr));
#ifndef QT_NO_SHORTCUT
        salir->setShortcut(QApplication::translate("MainWindow", "Ctrl+S", nullptr));
#endif // QT_NO_SHORTCUT
        actioncrear_archio_base->setText(QApplication::translate("MainWindow", "crear archio base", nullptr));
#ifndef QT_NO_SHORTCUT
        actioncrear_archio_base->setShortcut(QApplication::translate("MainWindow", "Ctrl+B", nullptr));
#endif // QT_NO_SHORTCUT
        actionobtener_version->setText(QApplication::translate("MainWindow", "obtener version", nullptr));
        actionmodificar_version->setText(QApplication::translate("MainWindow", "modificar version", nullptr));
#ifndef QT_NO_SHORTCUT
        actionmodificar_version->setShortcut(QApplication::translate("MainWindow", "Ctrl+B", nullptr));
#endif // QT_NO_SHORTCUT
        actioncopiar->setText(QApplication::translate("MainWindow", "copiar", nullptr));
#ifndef QT_NO_SHORTCUT
        actioncopiar->setShortcut(QApplication::translate("MainWindow", "Ctrl+C", nullptr));
#endif // QT_NO_SHORTCUT
        actioncortar->setText(QApplication::translate("MainWindow", "cortar", nullptr));
#ifndef QT_NO_SHORTCUT
        actioncortar->setShortcut(QApplication::translate("MainWindow", "Ctrl+X", nullptr));
#endif // QT_NO_SHORTCUT
        actionpegar->setText(QApplication::translate("MainWindow", "pegar", nullptr));
#ifndef QT_NO_SHORTCUT
        actionpegar->setShortcut(QApplication::translate("MainWindow", "Ctrl+V", nullptr));
#endif // QT_NO_SHORTCUT
        actioningresar_version->setText(QApplication::translate("MainWindow", "ingresar version", nullptr));
        actionmostrar_historial->setText(QApplication::translate("MainWindow", "mostrar historial", nullptr));
        menuarchivo->setTitle(QApplication::translate("MainWindow", "Archivo", nullptr));
        menumanejo_versiones->setTitle(QApplication::translate("MainWindow", "Manejo de Versiones", nullptr));
        menuedicion->setTitle(QApplication::translate("MainWindow", "edicion", nullptr));
        mainToolBar->setWindowTitle(QApplication::translate("MainWindow", "Herramientas", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H

/********************************************************************************
** Form generated from reading UI file 'ventana2.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VENTANA2_H
#define UI_VENTANA2_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_ventana2
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label;
    QLabel *label_2;

    void setupUi(QDialog *ventana2)
    {
        if (ventana2->objectName().isEmpty())
            ventana2->setObjectName(QStringLiteral("ventana2"));
        ventana2->resize(400, 300);
        buttonBox = new QDialogButtonBox(ventana2);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(50, 260, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label = new QLabel(ventana2);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(130, 10, 141, 20));
        label_2 = new QLabel(ventana2);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 30, 361, 191));
        QFont font;
        font.setPointSize(12);
        label_2->setFont(font);

        retranslateUi(ventana2);
        QObject::connect(buttonBox, SIGNAL(accepted()), ventana2, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), ventana2, SLOT(reject()));

        QMetaObject::connectSlotsByName(ventana2);
    } // setupUi

    void retranslateUi(QDialog *ventana2)
    {
        ventana2->setWindowTitle(QApplication::translate("ventana2", "historial de versiones", nullptr));
        label->setText(QApplication::translate("ventana2", "HISTORIAL DE VERSIONES", nullptr));
        label_2->setText(QApplication::translate("ventana2", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ventana2: public Ui_ventana2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VENTANA2_H

/********************************************************************************
** Form generated from reading UI file 'ventana.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VENTANA_H
#define UI_VENTANA_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPlainTextEdit>

QT_BEGIN_NAMESPACE

class Ui_ventana
{
public:
    QGridLayout *gridLayout;
    QLabel *label;
    QPlainTextEdit *plainText;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *ventana)
    {
        if (ventana->objectName().isEmpty())
            ventana->setObjectName(QStringLiteral("ventana"));
        ventana->resize(239, 137);
        gridLayout = new QGridLayout(ventana);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label = new QLabel(ventana);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        plainText = new QPlainTextEdit(ventana);
        plainText->setObjectName(QStringLiteral("plainText"));

        gridLayout->addWidget(plainText, 1, 0, 1, 1);

        buttonBox = new QDialogButtonBox(ventana);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout->addWidget(buttonBox, 2, 0, 1, 1);


        retranslateUi(ventana);
        QObject::connect(buttonBox, SIGNAL(accepted()), ventana, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), ventana, SLOT(reject()));

        QMetaObject::connectSlotsByName(ventana);
    } // setupUi

    void retranslateUi(QDialog *ventana)
    {
        ventana->setWindowTitle(QApplication::translate("ventana", "obtener versiones", nullptr));
        label->setText(QApplication::translate("ventana", "     ingrese el numero de version de que desea", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ventana: public Ui_ventana {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VENTANA_H

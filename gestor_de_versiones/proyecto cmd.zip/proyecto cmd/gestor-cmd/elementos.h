#ifndef ELEMENTOS_H
#define ELEMENTOS_H

#endif // ELEMENTOS_H
#include<qstring.h>
#include <stdio.h>
#include"matriz.h"

//ESTA CLASE CONTINE LOS ELEMENTOS QUE CONFORMAN LA MATRIZ DE VERSIONES

class arista;

class vertice{
 private:
   vertice *siguiente;
   arista *adyacente;
   QString version;
   int nversion;
   friend class matriz;
};

class arista{
    private:
        arista *siguiente;
        vertice *adyacente;
        QString version;
        int nversion;
        friend class matriz;
};


#include "menus.h"
#include<string.h>
#include<qstring.h>
#include<iostream>
#include<ctype.h>
using namespace std;

menus::menus(){
    abierto = false;
}

string menus::convertir_qstring_string(QString val){
    string b;
    b = val.toStdString();
    return b;
}

QString menus::convertir_string_qstring(string val){
    QString b;
    b = val.c_str();
    return b;
}

bool menus::verificar_numero(string p){
    if(p.length()== 0){
        return false;
    }
    if(p[0] == '+' || p[0] == '-'){
        return false;
    }
    for(int i = 0; i < p.length(); i++){
        if(!isdigit(p[i])){
            return false;
        }
    }
    return true;
}

void menus::menu_principal(){
    bool valido = false;
    string opcion;
    while(valido == false){
        cout << "eliga una opcion" << endl;
        cout << "1 - abrir archivo" << endl;
        cout << "2 - guardar archivo" << endl;
        cout << "3 - escribir texto" << endl;
        getline(cin, opcion);
        if(verificar_numero(opcion) == false){
            cout << "entrada erronea" << endl;
            valido = false;
        }
        if(verificar_numero(opcion) == true){
            if(opcion.length() == 0){
                cout << "entrada invalida" << endl;
                cout << "======================================" <<endl;
                valido = false;
            }
            if(opcion == "1"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_abrir();
            }
            if(opcion == "2"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_guardar();
            }
            if(opcion == "3"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_escribir();
            }
            cout << "entrada erronea" << endl;
            cout << "======================================" <<endl;
        }
    }
}

void menus::menu_escribir(){
    string te;
    string opcion;
    bool valido = false;
    cout << "escriba el texto que desee" << endl;
    getline(cin, te);
    texto = te;
    while(valido == false){
        cout << "eliga una opcion" << endl;
        cout << "1 - abrir archivo" << endl;
        cout << "2 - guardar archivo" << endl;
        getline(cin, opcion);
        if(verificar_numero(opcion) == false){
            cout << "entrada erronea" << endl;
            valido = false;
        }
        if(verificar_numero(opcion) == true){
            if(opcion.length() == 0){
                cout << "entrada invalida" << endl;
                valido = false;
            }
            if(opcion == "1"){
                cout << "entrada valida" << endl;
                valido = true;
                menu_abrir();
            }
            if(opcion == "2"){
                cout << "entrada valida" << endl;
                valido = true;
                menu_guardar();
            }
            cout << "entrada erronea" << endl;
        }
    }

}


void menus::menu_guardar(){
    string direccion;
    string nombre;
    string total;
    cout << "eliga la direccion donde desee guardar el archivo" << endl;
    getline(cin, direccion);
    cout << "nombre del archivo" << endl;
    getline(cin, nombre);
    total = total + direccion;
    total = total + nombre;
    archi->obtener_nombre(convertir_string_qstring(total));
    archi->guardar_archivo(convertir_string_qstring(total));
    archi->entrada_texto(convertir_string_qstring(texto));
    bool valido = false;
    string opcion;
    while(valido == false){
        cout << "eliga una opcion" << endl;
        cout << "1 - abrir archivo" << endl;
        cout << "2 - guardar archivo" << endl;
        cout << "3 - escribir texto" << endl;
        cout << "4 - crear archivo base" << endl;
        getline(cin, opcion);
        if(verificar_numero(opcion) == false){
            cout << "entrada erronea" << endl;
            valido = false;
        }
        if(verificar_numero(opcion) == true){
            if(opcion.length() == 0){
                cout << "entrada invalida" << endl;
                cout << "======================================" <<endl;
                valido = false;
            }
            if(opcion == "1"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_abrir();
            }
            if(opcion == "2"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_guardar();
            }
            if(opcion == "3"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_escribir();
            }
            if(opcion == "4"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_obtener();
            }
            cout << "entrada erronea" << endl;
            cout << "======================================" <<endl;
        }
    }

}

void menus::menu_abrir(){
    string direccion;
    cout << "eliga la direccion donde este el archivo que desea abrir" << endl;
    getline(cin, direccion);
    if(abierto == true){
        texto = "";
        mane->borrar_matriz();
        if(mane->get_existen() == true){
            mane->guardar_version(archi->get_nombre());
        }
        archi->set_nombre("");
        archi->obtener_nombre(convertir_string_qstring(direccion));
        archi->abrir_archivo(convertir_string_qstring(direccion));
        mane->set_existen(archi->verificar_versiones());
        if(mane->get_existen() == false){
            cout << "======================================" <<endl;
            cout << "no posee archivo de versiones" << endl;
            cout << "======================================" <<endl;
        }
        texto = convertir_qstring_string(archi->salida_texto());
        cout << "======================================" <<endl;
        cout << "el contenido del archivo es" << endl;
        cout << texto << endl;
        cout << "======================================" <<endl;
        if(mane->get_existen() == true){
            mane->cargar_versiones(archi->get_nombre());
            mane->ingresar_vertices();
            mane->ingresar_aristas();
            mane->generar_historial();
        }
        if(mane->get_existen() == false){
            menu_principal();
        }
        if(mane->get_existen() == true){
            bool valido = false;
            string opcion;
            while(valido == false){
                cout << "eliga una opcion" << endl;
                cout << "1 - abrir archivo" << endl;
                cout << "2 - guardar archivo" << endl;
                cout << "3 - escribir texto" << endl;
                cout << "4 - obtener version" << endl;
                cout << "5 - mostrar historial" << endl;
                getline(cin, opcion);
                if(verificar_numero(opcion) == false){
                    cout << "entrada erronea" << endl;
                    valido = false;
                }
                if(verificar_numero(opcion) == true){
                    if(opcion.length() == 0){
                        cout << "entrada invalida" << endl;
                        cout << "======================================" <<endl;
                        valido = false;
                    }
                    if(opcion == "1"){
                        cout << "entrada valida" << endl;
                        cout << "======================================" <<endl;
                        valido = true;
                        menu_abrir();
                    }
                    if(opcion == "2"){
                        cout << "entrada valida" << endl;
                        cout << "======================================" <<endl;
                        valido = true;
                        menu_guardar();
                    }
                    if(opcion == "3"){
                        cout << "entrada valida" << endl;
                        cout << "======================================" <<endl;
                        valido = true;
                        menu_escribir();
                    }
                    if(opcion == "4"){
                        cout << "entrada valida" << endl;
                        cout << "======================================" <<endl;
                        valido = true;
                        //menu_obtener(); //hacer funcion
                    }
                    if(opcion == "5"){
                        cout << "entrada valida" << endl;
                        cout << "======================================" <<endl;
                        valido = true;
                        menu_historial();
                    }
                    cout << "entrada erronea" << endl;
                    cout << "======================================" <<endl;
                }
            }

        }

    }

    if(abierto == false){
        archi->obtener_nombre(convertir_string_qstring(direccion));
        archi->abrir_archivo(convertir_string_qstring(direccion));
        mane->set_existen(archi->verificar_versiones());
        texto = convertir_qstring_string(archi->salida_texto());
        cout << "======================================" <<endl;
        cout << "el contenido del archivo es" << endl;
        cout << texto << endl;
        cout << "======================================" <<endl;
        if(mane->get_existen() == false){
            cout << "======================================" <<endl;
            cout << "no posee archivo de versiones" << endl;
            cout << "======================================" <<endl;
        }
        abierto = true;
                                                   //C:\Users\juan camilo\Desktop\proyecto cmd\prueba.txt
        if(mane->get_existen() == true){
            mane->cargar_versiones(archi->get_nombre());
            mane->ingresar_vertices();
            mane->ingresar_aristas();
            mane->generar_historial();
        }
        if(mane->get_existen() == false){
            menu_principal();
        }
        if(mane->get_existen() == true){
            bool valido = false;
            string opcion;
            while(valido == false){
                cout << "eliga una opcion" << endl;
                cout << "1 - abrir archivo" << endl;
                cout << "2 - guardar archivo" << endl;
                cout << "3 - escribir texto" << endl;
                cout << "4 - obtener version" << endl;
                cout << "5 - mostrar historial" << endl;
                getline(cin, opcion);
                if(verificar_numero(opcion) == false){
                    cout << "entrada erronea" << endl;
                    valido = false;
                }
                if(verificar_numero(opcion) == true){
                    if(opcion.length() == 0){
                        cout << "entrada invalida" << endl;
                        cout << "======================================" <<endl;
                        valido = false;
                    }
                    if(opcion == "1"){
                        cout << "entrada valida" << endl;
                        cout << "======================================" <<endl;
                        valido = true;
                        menu_abrir();
                    }
                    if(opcion == "2"){
                        cout << "entrada valida" << endl;
                        cout << "======================================" <<endl;
                        valido = true;
                        menu_guardar();
                    }
                    if(opcion == "3"){
                        cout << "entrada valida" << endl;
                        cout << "======================================" <<endl;
                        valido = true;
                        menu_escribir();
                    }
                    if(opcion == "4"){
                        cout << "entrada valida" << endl;
                        cout << "======================================" <<endl;
                        valido = true;
                        menu_obtener();
                    }
                    if(opcion == "5"){
                        cout << "entrada valida" << endl;
                        cout << "======================================" <<endl;
                        valido = true;
                        menu_historial();
                    }
                    cout << "entrada erronea" << endl;
                    cout << "======================================" <<endl;
                }
            }

        }
   }

}

void menus::menu_historial(){
    cout << "el historial de versiones es" << endl;
    cout << convertir_qstring_string(mane->get_historial());
    cout << "======================================" <<endl;
    bool valido = false;
    string opcion;
    while(valido == false){
        cout << "eliga una opcion" << endl;
        cout << "1 - abrir archivo" << endl;
        cout << "2 - guardar archivo" << endl;
        cout << "3 - escribir texto" << endl;
        cout << "4 - obtener version" << endl;
        cout << "5 - mostrar historial" << endl;
        getline(cin, opcion);
        if(verificar_numero(opcion) == false){
            cout << "entrada erronea" << endl;
            valido = false;
        }
        if(verificar_numero(opcion) == true){
            if(opcion.length() == 0){
                cout << "entrada invalida" << endl;
                cout << "======================================" <<endl;
                valido = false;
            }
            if(opcion == "1"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_abrir();
            }
            if(opcion == "2"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_guardar();
            }
            if(opcion == "3"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_escribir();
            }
            if(opcion == "4"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_obtener();
            }
            if(opcion == "5"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_historial();
            }
            cout << "entrada erronea" << endl;
            cout << "======================================" <<endl;
        }
    }
}

void menus::menu_obtener(){
    bool fil;
    fil = false;
    string version;
    while(fil == false){
        cout << "ingrese la version que deseea obtener" << endl;
        getline(cin, version);
        if(mane->filtro(convertir_string_qstring(version)) == false){
            cout << "dato erroneo, intente de nuevo" << endl;
            fil = false;
        }
        if(mane->filtro(convertir_string_qstring(version)) == true){
            cout << "el contenido de la version es" << endl;
            texto = convertir_qstring_string(mane->generar_delta(convertir_string_qstring(version)));
            cout << texto << endl;
            cout << "el delta generado es " << convertir_qstring_string(mane->get_supuesto()) << endl;
            fil = true;
            cout << "======================================" <<endl;
        }
    }
    bool valido = false;
    string opcion;
    while(valido == false){
        cout << "eliga una opcion" << endl;
        cout << "1 - escribir" << endl;
        cout << "2 - modificar" << endl;
        getline(cin, opcion);
        if(verificar_numero(opcion) == false){
            cout << "entrada erronea" << endl;
            valido = false;
        }
        if(verificar_numero(opcion) == true){
            if(opcion.length() == 0){
                cout << "entrada invalida" << endl;
                cout << "======================================" <<endl;
                valido = false;
            }
            if(opcion == "1"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_escribir2();
            }
            if(opcion == "2"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_modificar();
            }
            cout << "entrada erronea" << endl;
            cout << "======================================" <<endl;
        }
    }

}

void menus::menu_escribir2(){
    string te;
    string opcion;
    bool valido = false;
    cout << "escriba el texto que desee" << endl;
    getline(cin, te);
    texto = te;
    while(valido == false){
        cout << "eliga una opcion" << endl;
        cout << "1 - escribir" << endl;
        cout << "2 - modificar" << endl;
        getline(cin, opcion);
        if(verificar_numero(opcion) == false){
            cout << "entrada erronea" << endl;
            valido = false;
        }
        if(verificar_numero(opcion) == true){
            if(opcion.length() == 0){
                cout << "entrada invalida" << endl;
                valido = false;
            }
            if(opcion == "1"){
                cout << "entrada valida" << endl;
                valido = true;
                menu_escribir2();
            }
            if(opcion == "2"){
                cout << "entrada valida" << endl;
                valido = true;
                menu_modificar();
            }
            cout << "entrada erronea" << endl;
        }
    }
}

void menus::menu_modificar(){
    cout << "se ha modificado la version" << convertir_qstring_string(mane->get_supuesto()) << endl;
    mane->crear_version(convertir_string_qstring(texto));
    mane->guardar_version(archi->get_nombre());
    mane->cargar_versiones(archi->get_nombre());
    mane->ingresar_vertices();
    mane->ingresar_aristas();
    mane->generar_historial();
    bool valido = false;
    string opcion;
    while(valido == false){
        cout << "eliga una opcion" << endl;
        cout << "1 - abrir archivo" << endl;
        cout << "2 - guardar archivo" << endl;
        cout << "3 - escribir texto" << endl;
        cout << "4 - obtener version" << endl;
        cout << "5 - mostrar historial" << endl;
        getline(cin, opcion);
        if(verificar_numero(opcion) == false){
            cout << "entrada erronea" << endl;
            valido = false;
        }
        if(verificar_numero(opcion) == true){
            if(opcion.length() == 0){
                cout << "entrada invalida" << endl;
                cout << "======================================" <<endl;
                valido = false;
            }
            if(opcion == "1"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_abrir();
            }
            if(opcion == "2"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_guardar();
            }
            if(opcion == "3"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_escribir();
            }
            if(opcion == "4"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_obtener();
            }
            if(opcion == "5"){
                cout << "entrada valida" << endl;
                cout << "======================================" <<endl;
                valido = true;
                menu_historial();
            }
            cout << "entrada erronea" << endl;
            cout << "======================================" <<endl;
        }
    }
}

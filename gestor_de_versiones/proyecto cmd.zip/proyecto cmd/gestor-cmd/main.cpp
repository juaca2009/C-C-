#include <QCoreApplication>
#include<menus.h>
#include<string.h>
#include<qstring.h>
#include<ctype.h>
#include<manejador.h>
#include<ficheros.h>
using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    menus *men = new menus();
    men->menu_principal();

    return a.exec();
}

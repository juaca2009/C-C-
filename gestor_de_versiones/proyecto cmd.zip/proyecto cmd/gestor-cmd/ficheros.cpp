#include "ficheros.h"
#include<qstring.h>
#include<qfile.h>
#include<qtextstream.h>
#include<qdir.h>
#include<qdebug.h>


ficheros::ficheros(){

}

QString ficheros::salida_texto(){
    QTextStream io;
    QString t;
    io.setDevice(&arch);
    t = io.readAll();
    arch.flush();
    arch.close();
    return t;
}

void ficheros::abrir_archivo(QString nombre_arch){
    arch.setFileName(nombre_arch);
    arch.open(QIODevice::ReadOnly | QIODevice::Text);
}

bool ficheros::apertura(){
    return arch.isOpen();
}

QString ficheros::erro_string(){
    return arch.errorString();
}

void ficheros::guardar_archivo(QString nombre_arch){
    arch.setFileName(nombre_arch);
    arch.open(QIODevice::WriteOnly | QIODevice::Text);
}

void ficheros::entrada_texto(QString text){
    QTextStream io;
    io.setDevice(&arch);
    io << text;
    arch.close();
}

void ficheros::obtener_nombre(QString nom){
    /*
     * entradas: un qstring
     * salidas: obtiene el nombre de un archivo
     * retornos: ninguno
     * descripcion: obtiene el nombre del archivo de la direccion que se obtuvo al abrir un documento
     */
    int i;
    for(i = nom.length(); i > 0; i--){
        if(nom[i] == '/'){
            break;
        }
    }
    i = i + 1;
    for(int j = i; j < nom.length(); j++){
        nombre = nombre + nom[j];
    }
}

QString ficheros::get_nombre(){
    return nombre;
}

bool ficheros::verificar_versiones(){
    /*
     * entradas: ninguna
     * salidas: verifica si el archivo abierto tiene archivo de versiones
     * retornos: ninguno
     * descripcion: ESTA FUNCION ES IMPORTANTE verifica que el archivo abierto tenga archivo de versiones.
     */
    QDir directorio;
    QString direccion_defecto;
    QString nombre_version;                                             //SI SE PRESENTA ERRORES CAMBIE EL PATH DE LA DIRECCION POR DEFECTO, YA QUE ESTA PERTENCE A MI PC, LOS ARCHIVOS DE VERSIONES SE GENERAN
    QString nom;
    int tamano;                                                         // EN LA DIRECCION DONDE SE GUARDA EL ARCHIVO Y SE COMPILA, PARA SER MAS EXACTO EN LA CARPETA DE DEBUG QUE SE GENERA AL COMPILARSE.
    for(int j = 0; j < nombre.length(); j++){
        if(nombre[j] == '.'){
            break;
        }
        nom = nom + nombre[j];
    }
    nom = nom + ".txt";
    nombre_version = "s_";
    direccion_defecto = "C:\\Users\\juan camilo\\Documents\\UNIVERSIDAD\objetos\\trabajos\\proyecto\\proyecto cmd\\build-gestor-cmd-Desktop_Qt_5_10_1_MinGW_32bit-Debug";
    nombre_version = nombre_version + nom;
    directorio.setPath(direccion_defecto);
    tamano = directorio.count();
    for(int i = 2; i < tamano; i++){
        if(directorio[i] == nombre_version){
            return true;
        }
    }
    return false;

}

void ficheros::set_nombre(QString nom){
    nombre = nom;
}

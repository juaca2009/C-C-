#ifndef MENUS_H
#define MENUS_H
#include<string.h>
#include<qstring.h>
#include<ctype.h>
#include<manejador.h>
#include<ficheros.h>
using namespace std;


class menus{
    private:
        ficheros *archi = new ficheros();
        manejador *mane = new manejador();
        string texto;
        bool abierto;
    public:
        menus();
        string convertir_qstring_string(QString val);
        QString convertir_string_qstring(string val);
        bool verificar_numero(string p);
        void menu_principal();
        void menu_escribir();
        void menu_guardar();
        void menu_abrir();
        void menu_historial();
        void menu_obtener();
        void menu_escribir2();
        void menu_modificar();
};

#endif // MENUS_H

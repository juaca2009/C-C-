#include "matriz.h"
#include<qstring.h>
#include <stdio.h>
#include<qfile.h>

matriz::matriz(){

}

//inicia la matriz
void matriz::iniciar_vacio(){
    h = NULL;
}

bool matriz::vacio(){
    if(h == NULL){
        return true;
    }
    else{
        return false;
    }
}

int matriz::tamano(){
    int contador = 0;
    vertice *aux;
    aux = h;
    while(aux != NULL){
        contador = contador + 1;
        aux = aux->siguiente;
    }
    return contador;
}

bool matriz::existe(QString numero){
    /*
     * entradas: un qstring que en escencia es un numero de versio
     * salidas: determina si existe un elemento
     * retornos: un booleano
     * descripcion: retorna positivo en el caso de que la version solicitada exista
     */
    vertice *aux;
    arista *auxiliar;
    aux = h;
    while(aux != NULL){
        if(aux->version == numero){
            return true;
        }
        auxiliar = aux->adyacente;
        while(auxiliar != NULL){
            if(auxiliar->version == numero){
                return true;
            }
            auxiliar = auxiliar->siguiente;
        }
        aux = aux->siguiente;
    }
    return false;
}

void matriz::insertar_vertice(QString numero, int n_numero){
    /*
     * entradas: un qstring que es la version y un entero que es la misma version pero en forma entera
     * salidas: genera un nuevo vertice
     * retornos: ninguno
     * descripcion: mete un nuevo elemento a la rama principal, los acomoda de menor a mayor.
     */
    vertice *nuevo = new vertice;
    nuevo->version = numero;
    nuevo->nversion = n_numero;
    nuevo->adyacente = NULL;
    nuevo->siguiente = NULL;
    vertice *aux;
    bool bandera = false;
    aux = h;
    if(vacio()){
        h = nuevo;
    }
    else{
        if(cantidad_vertices() == 1){
            if(nuevo->nversion < aux->nversion){
                nuevo->siguiente = aux;
                bandera = true;
            }
            if(bandera == false){
                aux->siguiente = nuevo;
                bandera = true;
            }
        }
        if(cantidad_vertices() > 1){
           if(bandera == false){
               if(nuevo->nversion < aux->nversion){
                   nuevo->siguiente = aux;
                   bandera = true;
               }
           }

           if(bandera == false){
               while(aux->siguiente != NULL){
                   if(nuevo->nversion > aux->nversion && nuevo->nversion < aux->siguiente->nversion){
                       nuevo->siguiente = aux->siguiente;
                       aux->siguiente = nuevo;
                       bandera = true;
                       break;
                   }
                   aux = aux->siguiente;
               }
               if(bandera == false){
                   aux->siguiente = nuevo;
                   bandera = true;
               }
           }
        }
    }
}

vertice *matriz::get_vertice(QString numero){
    vertice *aux;
    aux = h;
    while(aux != NULL){
        if(aux->version == numero){
            return aux;
        }
        aux = aux->siguiente;
    }
    return NULL;
}

void matriz::insertar_arista(vertice *origen, QString numero, int n_numero){
    /*
     * entradas: un vertice de origen, una version en forma de qstring y la version en forma entera
     * salidas: genera una nueva rama
     * retornos: ninguno
     * descripcion: genera una nueva rama o fila en la matriz, se acomodan de menor a mayor
     */
    arista *nueva = new arista;
    nueva->version = numero;
    nueva->nversion = n_numero;
    nueva->siguiente = NULL;
    arista *aux;
    aux = origen->adyacente;
    if(aux == NULL){
        origen->adyacente = nueva;
    }
    else{
        bool bandera = false;
        if(cantidad_arista(origen) == 1){
            if(nueva->nversion < aux->nversion){
                nueva->siguiente = aux;
                origen->adyacente = nueva;
                bandera = true;
            }
            if(bandera == false){
                aux->siguiente = nueva;
                bandera = true;   //
            }
        }

        if(cantidad_arista(origen) > 1){
            if(bandera == false){
                if(nueva->nversion < aux->nversion){
                    nueva->siguiente = aux;
                    origen->adyacente = nueva;
                    bandera = true;
                }
            }
            if(bandera == false){
                while(aux->siguiente != NULL){
                    if(nueva->nversion > aux->nversion && nueva->nversion < aux->siguiente->nversion){
                        nueva->siguiente = aux->siguiente;
                        aux->siguiente = nueva;
                        bandera = true;
                        break;
                    }
                    aux = aux->siguiente;
                }
                if(bandera == false){
                    aux->siguiente = nueva;
                    bandera = true;
                }
            }

        }

    }
}

//eliminar matriz
void matriz::anular(){
    vertice *aux;
    while(h != NULL){
        aux = h;
        h = h->siguiente;
        delete(aux);
    }
}

int matriz::cantidad_arista(vertice *origen){
    arista *aux;
    int cont = 0;
    aux = origen->adyacente;
    if(aux == NULL){
        return cont;
    }
    else{
        cont = 1;
        while(aux->siguiente != NULL){
            cont = cont +1;
            aux = aux->siguiente;

        }
    }
    return cont;
}

int matriz::cantidad_vertices(){
    vertice *aux;
    int cont = 0;
    aux = h;
    if(vacio()){
        return cont;
    }
    else{
        cont = 1;
        while(aux->siguiente != NULL){
            cont = cont +1;
            aux = aux->siguiente;

        }
    }
    return cont;
}

QString matriz::obtener_ultimo_vertice(){
    vertice *aux;
    aux = h;
    while(aux->siguiente != NULL){
        aux = aux->siguiente;
    }
    return aux->version;
}

QString matriz::obtener_ultima_arista(vertice *origen){
    arista *aux;
    aux = origen->adyacente;
    while(aux->siguiente != NULL){
        aux = aux->siguiente;
    }
    return aux->version;
}

bool matriz::ultimo_vertice(QString numero){
    vertice *aux;
    aux = h;
    while(aux != NULL){
        if(aux->version == numero){
            if(aux->siguiente == NULL){
                return true;
            }
            else{
                return false;
            }
        }
        aux = aux->siguiente;
    }
}

bool matriz::ultima_arista(vertice *origen, QString numero){
    arista *aux;
    aux = origen->adyacente;
    while(aux != NULL){
        if(aux->version == numero){
            if(aux->siguiente == NULL){
                return true;
            }
            else{
                return false;
            }
        }
        aux = aux->siguiente;
    }
}


bool matriz::vertice_vacio(QString numero){
    /*
     * entradas: un version en forma de qstring
     * salidas: determina si un vertice tiene aristas
     * retornos: un booleano
     * descripcion: si el vertice no posee aristas o ramas retorna true.
     */
    vertice *aux;
    aux = h;
    while(aux != NULL){
        if(aux->version == numero){
            if(aux->adyacente == NULL){
                return true;
            }
            else{
                return false;
            }
        }
        aux = aux->siguiente;
    }
}

